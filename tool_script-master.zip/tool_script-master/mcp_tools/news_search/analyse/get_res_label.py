import json
import pandas as pd
from datetime import datetime
from time_utils import TimeUtils


class GetResultLabel:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/analyse/query_with_es_result.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/analyse/query_with_result_label.tsv"
        self.CORE_TAGS = ["军事", "财经", "科技", "金融", "娱乐", "国际", "国内", "民生", "经济"]

    def analyze_es_result(self, es_result_str, query_tag, query):
        try:
            es_result = json.loads(es_result_str)
        except:
            es_result = []

        has_result = 1 if len(es_result) > 0 else 0
        result_count_10 = 1 if len(es_result) == 10 else 0

        tags_list = [t.strip() for t in query_tag.split('&') if t.strip()]
        if len(es_result) == 0:
            features_tag_match = 0
            mismatch_count = 10
            query_tag_processed = []
        elif tags_list == ['新闻']:
            features_tag_match = 1
            mismatch_count = 0
            query_tag_processed = []
        else:
            query_tag_processed = [t for t in tags_list if t != '新闻']
            mismatch_count = 0

        is_mismatch = False
        core_count_in_query = len([t for t in query_tag_processed if t in self.CORE_TAGS])
        if 1 <= core_count_in_query <= 3:
            features_tag_richness = 1
        else:
            richness_ratios = []
            tag_richness_count = set()
            for item in es_result:
                try:
                    features = json.loads(item.get('features', '{}'))
                    features_tag = features.get('tag', '')
                    tags = [t.strip() for t in features_tag.split('&') if t.strip()]
                    for qt in query_tag_processed:
                        if qt not in features_tag:
                            is_mismatch = True
                            # mismatch_count += 1
                    # core_count = sum(1 for tag in tags if tag in self.CORE_TAGS)
                    for tag in tags:
                        if tag in self.CORE_TAGS:
                            tag_richness_count.add(tag)
                    # richness_ratios.append(core_count / len(self.CORE_TAGS))
                except:
                    # mismatch_count += 1
                    richness_ratios.append(0)
                if is_mismatch:
                    mismatch_count += 1
            # features_tag_richness = round(sum(richness_ratios) / len(richness_ratios), 3) if richness_ratios else 0
            features_tag_richness = round(len(tag_richness_count) / len(self.CORE_TAGS), 3)

        features_tag_match = 1 if tags_list == ['新闻'] or mismatch_count == 0 else 0
        features_tag_mismatch_count = mismatch_count
        if features_tag_match == 0 or result_count_10 == 0:
            features_tag_richness = 0

        # 时效性
        start_time, end_time = TimeUtils.get_time_range(query)
        out_of_range_flag = 0
        for item in es_result:
            publish_time = item.get('publish_time')
            if publish_time:
                try:
                    pub_dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
                    if not (start_time <= pub_dt <= end_time):
                        out_of_range_flag = 1
                        break
                except:
                    out_of_range_flag = 1
                    break

        return pd.Series([
            has_result,
            result_count_10,
            features_tag_match,
            features_tag_mismatch_count,
            features_tag_richness,
            out_of_range_flag
        ])

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        df[["是否有结果", "结果数量是否达到10条", "结果TAG是否与query TAG匹配",
            "结果TAG与query TAG不匹配的数量", "结果丰富度", "时效性"]] = \
            df.apply(lambda x: self.analyze_es_result(x["es_search_result"], x["query_tag"], x["query"]), axis=1)
        df.to_csv(self.output_path, sep="\t", index=False)


if __name__ == "__main__":
    obj = GetResultLabel()
    obj.process()
