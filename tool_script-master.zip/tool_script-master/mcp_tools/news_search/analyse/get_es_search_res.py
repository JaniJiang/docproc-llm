import json
import pandas as pd
import requests
from time_utils import TimeUtils
from itertools import combinations


class GetEsSearchResult:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/analyse/query_with_tag.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/analyse/query_with_es_result.tsv"

        self.es_search_path = "https://es-search-test.inner.chj.cloud/es_search"
        self.headers = {"Content-Type": "application/json"}
        self.index_name = "news_data_202510_all_v3"
        self.size = 10
        self.minimum_should_match = 1

        self.default_news_tags = ["军事", "财经", "科技", "金融", "娱乐", "国际", "国内"]
        self.boost_map = {
            "军事": 1,
            "财经": 1,
            "国内": 2,
            "科技": 1,
            "国际": 1,
            "金融": 2,
            "娱乐": 1,
        }

    def build_es_dsl(self, query: str, query_tag: str):
        if not query_tag.strip():
            tags = self.default_news_tags
        elif query_tag.strip() == "新闻":
            tags = self.default_news_tags
        else:
            tags = [tag.strip() for tag in query_tag.split("&") if tag.strip() and tag != "新闻"]
            if not tags:
                tags = self.default_news_tags

        if len(tags) == 1:  # 单个 tag -> must
            bool_query = {"must": [{"match_phrase": {"features": tags[0]}}]}
        else:  # 多个 tag -> should

            # # 方案3: 对 tag 进行组合召回
            # pairwise_clauses = []
            # for tag1, tag2 in combinations(tags, 2):
            #     # 每个组合都生成一个 bool must 子句，要求同时匹配这两个标签
            #     pairwise_clauses.append({
            #         "bool": {
            #             "must": [
            #                 {"match_phrase": {"features": tag1}},
            #                 {"match_phrase": {"features": tag2}}
            #             ]
            #         }
            #     })

            # bool_query = {
            #     "should": pairwise_clauses,
            #     "minimum_should_match": 1  # 至少匹配一对标签组合
            # }

            # 方案 2: 按照权重高低召回
            should_clauses = [
                {
                    "match": {
                        "features": {
                            "query": tag,
                            "boost": self.boost_map.get(tag, 1)  # 默认权重1
                        }
                    }
                }
                for tag in tags
            ]

            bool_query = {
                "should": should_clauses,
                "minimum_should_match": self.minimum_should_match,
            }

            # 方案 1: 直接召回
            # bool_query = {
            #     "should": [{"match": {"features": t}} for t in tags],
            #     "minimum_should_match": self.minimum_should_match,
            # }

        start, end = TimeUtils.get_time_range(query)

        dsl = {
            "query": {
                "bool": {
                    "must": [
                        {"bool": bool_query},
                        {
                            "range": {
                                "publish_time": {
                                    "gte": start.strftime("%Y-%m-%d %H:%M:%S"),
                                    "lte": end.strftime("%Y-%m-%d %H:%M:%S"),
                                    "format": "yyyy-MM-dd HH:mm:ss",
                                }
                            }
                        },
                    ]
                }
            },
            "size": self.size,
        }
        return dsl

    def get_es_result(self, query: str, query_tag: str):
        payload = {
            "index_name": self.index_name,
            "dsl": self.build_es_dsl(query, query_tag),
        }
        try:
            resp = requests.post(
                self.es_search_path,
                headers=self.headers,
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                timeout=20,
            )
            if resp.status_code == 200:
                return resp.json()
            else:
                print(f"请求失败: {resp.status_code} {resp.text}")
                return []
        except Exception as e:
            print(f"请求异常: {e}")
            return []

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        df = df.sample(n=min(100, len(df)), random_state=42)
        with open(self.output_path, "w", encoding="utf-8") as fout:
            fout.write("query\tquery_tag\tes_search_result\n")
            for idx, row in df.iterrows():
                query = str(row["query"])
                query_tag = str(row["query_tag"])
                if not query_tag.strip():
                    fout.write(f"{query}\t{query_tag}\t\n")
                    continue
                print(f"{idx}: 查询 {query_tag}（query={query}）...")
                es_result = self.get_es_result(query, query_tag)
                fout.write(f"{query}\t{query_tag}\t{json.dumps(es_result, ensure_ascii=False)}\n")


if __name__ == "__main__":
    obj = GetEsSearchResult()
    obj.process()
