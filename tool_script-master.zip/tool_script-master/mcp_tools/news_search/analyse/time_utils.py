from datetime import datetime, timedelta


class TimeUtils:
    @staticmethod
    def get_time_range(query: str):
        # now = datetime.now()
        now = datetime.strptime("2025-10-09 23:59:59", "%Y-%m-%d %H:%M:%S")

        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        today_end = now
        yesterday_start = today_start - timedelta(days=1)
        yesterday_end = today_start - timedelta(seconds=1)
        monday_this_week = today_start - timedelta(days=today_start.weekday())
        monday_last_week = monday_this_week - timedelta(days=7)
        sunday_last_week = monday_this_week - timedelta(seconds=1)
        first_day_this_month = today_start.replace(day=1)
        last_month_end = first_day_this_month - timedelta(seconds=1)
        first_day_last_month = last_month_end.replace(day=1)

        if any(k in query for k in ["最近", "这两天", "近期", "前两天"]):
            start = now - timedelta(days=3)
            end = now
        elif any(k in query for k in ["最近一周", "近一周", "一周内", "最近一星期"]):
            start = now - timedelta(days=7)
            end = now
        elif any(k in query for k in ["本周", "这周", "这一周", "这一星期", "本星期"]):
            start = monday_this_week
            end = now
        elif any(k in query for k in ["上周", "上星期", "上一星期", "上个礼拜", "上一礼拜"]):
            start = monday_last_week
            end = sunday_last_week
        elif any(k in query for k in ["本月", "这个月", "当月"]):
            start = first_day_this_month
            end = now
        elif any(k in query for k in ["上个月", "上月"]):
            start = first_day_last_month
            end = last_month_end
        elif any(k in query for k in ["今天", "当天", "早间", "午间", "晚间"]):
            if "早间" in query:
                start = today_start.replace(hour=0)
                end = today_start.replace(hour=12)
            elif "午间" in query:
                start = today_start.replace(hour=12)
                end = today_start.replace(hour=18)
            elif "晚间" in query:
                start = today_start.replace(hour=18)
                end = today_start.replace(hour=23, minute=59, second=59)
            else:
                start = today_start
                end = today_end
        elif "昨天" in query:
            start = yesterday_start
            end = yesterday_end
        elif "前天" in query:
            start = yesterday_start - timedelta(days=1)
            end = yesterday_end - timedelta(days=1)
        else:
            start = today_start
            end = today_end

        return start, end
