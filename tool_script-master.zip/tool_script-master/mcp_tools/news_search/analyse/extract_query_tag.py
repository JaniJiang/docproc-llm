import json
import pandas as pd
from recommend.struct_display_new.analyse.analyse_entitylink_news.step0_extract_tag_engine import ExtraxtTagFromQueryAndTitle


class ExtractQueryTag():
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/analyse/query.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/analyse/query_with_tag.tsv"
        self.extractor = ExtraxtTagFromQueryAndTitle()

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")

        with open(self.output_path, "w", encoding="utf-8") as fout:
            fout.write("query\tquery_tag\n")
            for idx, row in df.iterrows():
                query = row["query"]
                query_response = self.extractor.process({"text": query, "type": "query"})
                query_res = query_response.get("res", {})

                if isinstance(query_res, str):
                    try:
                        query_res = json.loads(query_res)
                    except Exception:
                        query_res = {}

                query_tag = query_res.get("tag", "") if isinstance(query_res, dict) else ""
                print(f"{idx}: query = {query}, tag = {query_tag}")

                fout.write(f"{query}\t{query_tag}\n")


if __name__ == "__main__":
    obj = ExtractQueryTag()
    obj.process()
